#####################################################
#### Vegetation phenology using phenofit library ####
#####################################################
#' sources:
#' phenofit paper:
#' https://besjournals.onlinelibrary.wiley.com/doi/full/10.1111/2041-210X.13870
#' phenofit vignette: 
#' https://cran.r-project.org/web/packages/phenofit/vignettes/phenofit-procedures.html

#' goal: 
#' - derive NDVI time series from multi-temporal NDVI raster data
#' - pre-processing of NDVI time series for use in phenofit()
#' - identify different growing seasons within the NDVI time series (rough curve fitting)
#' - reconstruct a daily NDVI curve from the NDVI time series (fine curve fitting)
#' - derive phenological metrics from reconstructed NDVI profile

### install/load necessary libraries
library(dplyr)
library(sf)
library(tidyterra)
library(ggplot2)
library(maptiles)
library(phenofit)
library(grid) # for plotting of fine curve fits
library(stringr) # for date extraction
library(RStoolbox)

#setwd(path_to_scripts_folder)

#---------------------------------------------------------------------------------------------------
# preparation of multi-temporal raster data for use in phenofit
#---------------------------------------------------------------------------------------------------

####################################################################################################
###### step 1) download VI time series with necessary quality layers
####################################################################################################

# download raster data for instance MODIS MOD13A1 
# 16-day Vegetation Index (VI) values at a per pixel basis at 500 meter (m) spatial resolution
# Link to product website: https://lpdaac.usgs.gov/products/mod13a1v061/

# GUI: https://appeears.earthdatacloud.nasa.gov (read documentation or ask web on bulk download)

# Google Earth Engine (GEE): 
# you can find the GEE code used for this example here: '.\GEE_MOD13A1.txt'
# data processed by GEE and save on your Google Drive account can also be downloaded via R:
# https://googledrive.tidyverse.org/

####################################################################################################
####### step 2) add VI time series information to pts data
####################################################################################################

# load pts samples (10 samples in cropland, could also be tracked locations of animals)
pts <- st_read('../data/crop_samples.gpkg', quiet = TRUE) %>% 
  st_transform(., 'epsg:4326') %>% # crs of downloaded NDVI data
  mutate(id = c(1:n())) %>% 
  terra::vect()

# list MOD13A2 NDVI files
NDVI_rs_lst <- list.files('../data/NDVI_MOD13A1_2021_2023/', full.names = TRUE)
NDVI_rs_lst

# loop through NDVI_rs_lst and extract values for crop_smp
pts_NDVI_lst <- lapply(NDVI_rs_lst, function(i){
  # load raster i
  img <- terra::rast(i)
  # date from filename
  Date <- as.Date(str_extract(basename(i), "\\d{4}_\\d{2}_\\d{2}"), format = "%Y_%m_%d")
  # extract
  pts_img <- terra::extract(img, pts) %>% 
    as_tibble() %>% 
    mutate(date = Date,
           t = phenofit::getRealDate(date, DayOfYear), # date = comopsite date; t = image date
           y = NDVI/1e4, # scaling factor, as measurements are stored as integers
           year = as.numeric(format(date,"%Y"))) %>% 
    select(-DOY)
  # return
  return(pts_img)
})

# convert to df
NDVI_df <- do.call(rbind, pts_NDVI_lst) 

# filter to one ID (equals one location in pts)
# here we chose 5
mod <- NDVI_df %>% 
  filter(ID == 5)

# where is ID 5
pts_1 <- st_as_sf(pts) %>% 
  st_transform(., 3035)

# load raster
s2 <- rast('../data/S2_10_Bands_10m_crop_3035.tif')

# plot pts on raster
ggRGB(s2, r = 3, g = 2, b = 1, geom_raster = TRUE, stretch = 'lin') +
  geom_sf(data = pts_1 %>% filter(id == 5), color = 'red')

# plot NDVI of pt for all years (one year)
ggplot(mod, # %>% filter(year == 2022), 
       aes(x = date, y = y)) +
  geom_point(color = 'darkgreen') +
  scale_y_continuous(limits = c(0,1)) +
  labs(x = 'Date', y = 'NDVI')


#---------------------------------------------------------------------------------------------------
# prepare NDVI time series: initialize weights (indicating quality of VI measurements)
#---------------------------------------------------------------------------------------------------

# using phenofit::qcFUN
# overview of available functions for different sensors: phenofit::qc_summary()

# for the here used example (MOD13A1) its qc_summary
# add qc_flag and weight (w)
# weight: 1.0 = good; 0.5 = marginal; 0.2 = bad (clouds, snow)

mod$QC_flag <- phenofit::qc_summary(mod$SummaryQA)[[1]]
mod$w <- phenofit::qc_summary(mod$SummaryQA)[[2]]

#---------------------------------------------------------------------------------------------------
# prepare NDVI time series: pre-process input VI
#---------------------------------------------------------------------------------------------------
# Check input data, interpolate NA values in y (NDVI), remove spike values, 
# and set weights for NA in y and w.

Input <- phenofit::check_input(t = mod$t, 
                               y = mod$y,
                               w = mod$w,
                               QC_flag = mod$QC_flag,
                               nptperyear = 23, # from 16-day temporal resolution
                               # maxgap allowed to interpolate missing values, default, 
                               # see maxgap documentation for further info
                               maxgap = 23 / 4, 
                               wmin = 0.2) # minimum weight of bad points, default


#---------------------------------------------------------------------------------------------------
# growing season division 
# (rough curve fitting, captures vegetations gradual signal)
#---------------------------------------------------------------------------------------------------

# identifies different growing seasons in the VI time series
# this is an important step, especially if you have multiple growing seasons in a pixel,
# e.g. summer, winter wheat, multi-mown grassland etc. 
# not specifying the growing seasons appropriately can lead to wrong phenological metrics

# at the very basis, this function ensures that only one peak and two throughs are found within 
# one growing season

# define breaks
brks <- phenofit::season_mov(Input,
                             list(
                               ##### rough fitting params #####
                               rFUN = "smooth_wWHIT", # name of rough curve fitting function, default
                               # the name of weights updating functions, default,
                               # (applied after each iteration to adjust the weights of over/underestimated points)
                               wFUN = 'wTSM', 
                               maxExtendMonth = 3, # TODO: not really sure what this is for
                               # the number of rough fitting iterations, default, if users want to retain 
                               # signal of multiple season within a year, than 1-2 iterations max 
                               #(explanation in phenofit paper)
                               iters = 2, 
                               ##### growing season division params #####
                               wmin = 0.2, # minimum weight of bad points
                               r_min = 0.1 #r_max and r_min are used to eliminate fake peaks and troughs.
                             ))

# plot breaks
plot_season(Input, brks)

# smoothed VI curve from the two iterations of rough fitting are used to identify local peaks/throughs
# some additional criteria need to be satisfied when identifying the peaks/throughs to avoid 
# fake growing season peaks/throughs, otherwise they get removed (explanation in phenofit paper) 

# you can also use rough curve fitting object and skip fine curve fitting tzo derive phenological 
# metrics
# then you would need to use this function to generate the rough_fit object: r_fit <- brks2rfit(brks)



#---------------------------------------------------------------------------------------------------
# reconstruct daily NDVI profiles 
# (fine curve fitting, captures vegetation's rapid changes within a growing season)
#---------------------------------------------------------------------------------------------------

fit <- phenofit::curvefits(INPUT = Input, 
                           brks = brks,
                           list(
                             # curve fitting methods, there are others too, see documentation
                             methods = c("AG", "Zhang", "Beck", "Elmore"), 
                             wFUN = 'wTSM', # name of weights updating function (see season_mov())
                             iters = 2, # max number of iterations
                             wmin = 0.2, # min weights in the weights updating procedure
                             nextend = 2,
                             maxExtendMonth = 1, # TODO: same here, not really sure what this is for
                             minExtendMonth = 0.5, # TODO: same here, not really sure what this is for
                             # if the percentage of good- and marginal- quality points is less than 
                             # minPercValid, curve fiting result is set to NA.
                             minPercValid = 0 # default, should not be used 
                           ))

# get fits 
dfit <- get_fitting(fit)
print(dfit)

# plot fits (phenofit method)
g <- plot_curvefits(dfit, brks)
grid::grid.newpage()
grid::grid.draw(g)

#---------------------------------------------------------------------------------------------------
# get phenological metrics from reconstructed NDVI profiles
#---------------------------------------------------------------------------------------------------

TRS <- c(0.1, 0.2, 0.5) # threshold for PhenoTRS

# get phenological metrics
l_pheno <- get_pheno(fit, TRS = TRS, IsPlot = T) 
print(l_pheno$doy$Beck)


