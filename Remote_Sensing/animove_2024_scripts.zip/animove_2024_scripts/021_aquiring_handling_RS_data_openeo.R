###############################################################
#### Acquire RS data via Copernicus dataspace back-end ########
###############################################################
# link to website: https://documentation.dataspace.copernicus.eu/APIs/openEO/R_Client/R.html
# link to getting started: https://docs.openeo.cloud/getting-started/r/#authentication

#' goal:
#' acquire Sentinel-2 data for AOI in Radolfzell, Germany from Copernicus dataspace back-end

# load/install necessary libraries
library(openeo)
library(sf)
library(terra)
library(RStoolbox)
library(ggplot2)
library(dplyr)

#setwd(path_to_scripts_folder)

# connect to the back-end and login
connection <- openeo::connect(host = "https://openeo.dataspace.copernicus.eu")
login()
# prompts you to add login credentials on the Copernicus dataspace website and grant access


# assign the graph-building helper object to p for easy access to all openEO processes
# see > ?processes()
p <- processes()

# create variables for loading collection
# load S2 footprint
foot <- st_read('../data/S2_footprint_3035.gpkg')  
# foot_wgs84 <- st_read('../data/S2_footprint_SouthAmerica_4326.gpkg')
foot_wgs84 <- st_transform(foot, 'epsg:4326') # wgs84
bbox_foot <- st_bbox(foot_wgs84)

# set spatial extent to footprint
ext <- list(west = bbox_foot[[1]], south = bbox_foot[[2]], 
            east = bbox_foot[[3]], north = bbox_foot[[4]])
# temporal extent
t <- c("2023-06-13", "2023-06-13") # 1 day
# t <- c("2023-06-01", "2023-06-13") # multiple dates for bulk downloads

# load first datacube for defined spatial and temporal extent
# Sentinel-2 Level 2A
cube_s2 <- p$load_collection(
  id = "SENTINEL2_L2A",
  spatial_extent = ext,
  temporal_extent = t #, bands = c('Bandname1', 'Bandname2')
)

# get some information on the loaded collection
s2 <- describe_collection("SENTINEL2_L2A") # or use the collection entry from the list, e.g. collections$`COPERNICUS/S2`
print(s2)

# extract bandnames from s2
bandnames <- unlist(s2$`cube:dimensions`$bands$values)
bandnames
# list file formats for saving the result
formats <- list_file_formats()

# save using save_result, give format via list
res <- p$save_result(data = cube_s2, format = formats$output$GTiff)

# send job to back-end
job <- create_job(graph = res, title = "S2_Radolfzell")
# job <- create_job(graph = res, title = "S2_SouthAmerica")

##################################
# start job 
##################################
start_job(job = job)
# takes some time

##################################
# list job status
###################################
jobs_status <- list_jobs()

jobs_ls <- lapply(1:length(jobs_status), function(i){
  df <- do.call(cbind.data.frame, jobs_status[[i]]) %>%  
    dplyr::select(created, id, status, updated)
  return(df)
})
jobs_df <- do.call(rbind, jobs_ls) %>% 
  arrange(created)

jobs_df

##################################
# list the processed resultest
##################################
list_results(job = job)

#########################################################
# download all the files into a folder on your computer
#########################################################

# dir.create("../data/S2data_Radolfzell_openeo", showWarnings = FALSE)
download_results(job = job, folder = "../data/S2data_Radolfzell_openeo")

# dir.create("../data/S2data_SouthAmerica_openeo", showWarnings = FALSE)
# download_results(job = job, folder = "../data/S2data_SouthAmerica_openeo")

####################################
# load and and inspect result
####################################

S2_openeo <- rast('../data/S2data_Radolfzell_openeo/openEO_2023-06-13Z.tif')
S2_openeo
bandnames

# add bandnames
# !!! careful, this works only if you actually downloaded all bands in the collection
names(S2_openeo)
names(S2_openeo) <- bandnames
names(S2_openeo)

# plot RGB image
ggRGB(S2_openeo,r = 'B04', g = 'B03', b = 'B02', geom_raster = TRUE,
      stretch = 'lin')

####################################
# mask clouds using SCL layer
####################################

# plot scene classification layer
plot(S2_openeo[['SCL']])

# scl band (produced by Sen2Cor): scene classification layer can give you information on clouds, 
# cloud shadow, snow etc.
# see website for further information: 
# https://www.sentinel-hub.com/faq/how-get-s2a-scene-classification-sentinel-2/
# 7,8,9 = low, medium and high probability clouds 

# create cloud mask
cld_msk <- terra::ifel(S2_openeo[['SCL']] %in% c(7, 8, 9), NA, 1)
plot(cld_msk)

# mask clouds in bands B01 to B12
# define the bands you want to mask
bands_to_mask <- bandnames[1:12]
bands_to_mask

# apply the mask 
s2_msked <- terra::mask(S2_openeo[[bands_to_mask]], cld_msk)

# check if worked
plot(S2_openeo[['B04']])
plot(s2_msked[['B04']])

# transform to EPSG: 3035
s2_msked_3035 <- terra::project(s2_msked, 'epsg:3035', method = 'near')
s2_msked_3035
