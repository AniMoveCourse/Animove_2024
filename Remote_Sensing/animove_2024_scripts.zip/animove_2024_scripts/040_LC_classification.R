######################################
#### Generate a LC classification ####
######################################

#' goal: 
#' - features: we generate a data cube from all the spatial raster layers we created previously 
#' - response: we collect (or just use) reference data (vector format) 
#' - we extract feature values at reference data locations
#' - we use locations with features/response info to train a model and generate a 
#'   land cover (LC) classification
#' - we conduct an accuracy assessment of the LC classification

### install/load necessary libraries
library(terra)
library(raster) # required for mapview/mapedit; does not work with terra::rast()
library(sf)
library(RStoolbox)
library(ggplot2)
library(stars)
library(mapview)
library(mapedit)
library(dplyr)
library(caret)
library(randomForest)
library(irr) # for kappa function

#setwd(path_to_scripts_folder)

#---------------------------------------------------------------------------------------------------
# generate a data cube containing features
#---------------------------------------------------------------------------------------------------

# list all raster files we crated
raster_files <- list.files('../data/', pattern = '.tif', full.names = TRUE)
raster_files

# data we want to consider in the data cube
#' 1) s2 stack with the 10 spectral bands
#' 2) NDVI/NDWI (RStoolbox)
#' 3) distance
#' 4) edges
#' 5) smooth: 300/500

# remove ghs and s2 wgs84 
raster_files <- raster_files[grep(raster_files, pattern = 'GHS|wgs84|LC_class', invert = TRUE)]
raster_files
# remove terra NDVI
raster_files <- raster_files[grep(raster_files, pattern = 'terra', invert = T)]

# create .vrt stack
# filename
vrt_datacube <- '../data/vrt_datacube.vrt'
# build .vrt
# build vrt
terra::vrt(raster_files, vrt_datacube, "-separate", overwrite = T)

# load vrt
datacube <- terra::rast(vrt_datacube)
datacube
# rename bands
names(datacube)
# vector with original S2 bandnames
bandnames <- c('distance', 'edge', 'NDVI', 'NDWI',
               "B02", "B03", "B04",  "B08", "B05", "B06", "B07", "B08a", "B11", "B12",
               'smooth_300', 'smooth_500')

# change bandnames 
names(datacube) <- bandnames
names(datacube)
crs(datacube)

# plot(datacube[['NDVI']])

####################################################################################################
# side note: what to do if the raster layers you want to include in the data cube cannot be 
# matched (you get an error, due to, e.g., differences in extent, crs or resolution)
####################################################################################################

#' --> look at the script from Martina Scacco, which tackles many of the problems related to that 
#' issue
#' you can find the script here: './000_SideNote_AlignStackRasterLayers.R'

#---------------------------------------------------------------------------------------------------
# generate training data (if time is already short, skip this part and go to 
# shortcut: reference data)
#---------------------------------------------------------------------------------------------------

# load s2 stack in raster format
# note using raster instead of terra is necessary here, because mapview/mapedit does only work with
# raster
s2_raster <- raster::brick('../data/S2_10_Bands_10m_crop_3035.tif') 

# generate reference polygons for 4 LC classes
#' forest
#' urban
#' water
#' vegetation

#===================================================================================================
# LEARNING TASK: 
# - generate 10 polygons for each LC class
# - if time is short, skip this part and go to shortcut
#===================================================================================================

# forest
map <- mapview::viewRGB(s2_raster, r=3, g=2, b=1, maxpixels = 1000000) 
forest <- mapedit::drawFeatures(map = map)
# add LC attribute
forest$LC <- "forest"

# urban 
map <- mapview::viewRGB(s2_raster, r=3, g=2, b=1, maxpixels = 1000000) 
urban <- mapedit::drawFeatures(map = map)
# add LC attribute
urban$LC <- "urban"

# water 
map <- mapview::viewRGB(s2_raster, r=3, g=2, b=1, maxpixels = 1000000) 
water <- mapedit::drawFeatures(map = map)
# add LC attribute
water$LC <- "water"

# vegetation
map <- mapview::viewRGB(s2_raster, r=3, g=2, b=1, maxpixels = 1000000) 
vegetation <- mapedit::drawFeatures(map = map)
# add LC attribute
vegetation$LC <- "vegetation"

# soil/crop land
map <- mapview::viewRGB(s2_raster, r=3, g=2, b=1, maxpixels = 1000000) 
soil <- mapedit::drawFeatures(map = map)
# add LC attribute
soil$LC <- "soil"


# combine to one layer and add numeric class id
ref <- rbind(forest, urban, water, vegetation) %>% 
  group_by(LC) %>% 
  mutate(class_id = cur_group_id()) %>%  # assign numeric class id
  ungroup()
# plot
plot(ref)
st_crs(ref)
# convert to 3035
ref_3035 <- st_transform(ref, 'epsg:3035')

# save
st_write(ref_3035, '../data/myownref.gpkg', delete_layer = TRUE)

#---------------------------------------------------------------------------------------------------
# shortcut: reference data for generating response variable
#---------------------------------------------------------------------------------------------------

# load pre-existing reference data
ref_pre <- st_read('../data/reference_data.gpkg') %>% 
  group_by(LC) %>% 
  mutate(class_id = cur_group_id()) %>%  # assign numeric class id
  ungroup()

#' classes
#' 1 = forest
#' 2 = soil
#' 3 = urban
#' 4 = vegetation
#' 5 = water

st_crs(ref_pre)

# plot ref samples on top of rgb
ggRGB(datacube, r = 7, g = 6, b = 5, geom_raster = TRUE, stretch = 'lin') +
  geom_sf(data = ref_pre, aes(fill = as.factor(class_id)))
  # scale_fill_manual(values = c('1' = "darkgreen", 
  #                              '2' = "sandybrown",
  #                              '3' = "red",
  #                              '4' = "green",
  #                              '5' = 'blue'))


### Sample points within the ref polygons
# to get labeled features, we need points to extract features for from the datacube
# let's randomly select some points in our polygons and save there labels to them
labeled_points_ls <- list()
for(i in unique(ref_pre$class_id)){
  message(paste0("Sampling points from polygons with class_id=", i))
  # sample points for polygons of class_id = i
  labeled_points_ls[[i]] <- st_sample(
    x = ref_pre[ref_pre$class_id == i,], 
    type = "random", 
    size = 100
  )
  labeled_points_ls[[i]] <- st_as_sf(labeled_points_ls[[i]])
  labeled_points_ls[[i]]$class_id <- i
}

# list with labeled pts to df
labeled_points <- do.call(rbind, labeled_points_ls)
head(labeled_points)
table(labeled_points$class_id)

# Here are the 100 points we sampled within the 1st class (forest)
ggplot() +
  geom_sf(data=ref_pre, col=ref_pre$class_id) +
  geom_sf(data=labeled_points_ls[[1]], col='darkgreen')

#---------------------------------------------------------------------------------------------------
# extract feature values for reference pts
#---------------------------------------------------------------------------------------------------

# now that we have the reference data (labeled_points) we need to extract feature values (datacube)
# at reference data locations

# extract raster values at pts (features)
labeled_points_vect <- terra::vect(labeled_points) 
features <- terra::extract(datacube, labeled_points)

# add class_ID to features
labeled_features_interim <- cbind(labeled_points_vect,  features[, !names(features) %in% 'ID']) %>% 
  as_tibble()

# remove na and duplicates
labeled_features <- labeled_features_interim %>% 
  na.omit() %>% 
  dplyr::distinct(.keep_all = TRUE)

#---------------------------------------------------------------------------------------------------
# generate LC classification with random forest (RF) algorithm
#---------------------------------------------------------------------------------------------------

set.seed(455351) # why? because we will use random forest to fit the model 
# by setting a set the results can be reproduced, given the input data remains equals


# separate labeled_features dataset in response (y) and predictor (features, x) variables
x <- labeled_features[,2:ncol(labeled_features)] # remove ID column
y <- as.factor(labeled_features$class_id) # we want caret to treat this as categories, thus factor
levels(y) <- paste0("class_", levels(y))
# if response is left numeric, RF regression instead of classification is performed

# fit the RF model
model <- caret::train(
  x = x,
  y = y, 
  trControl = trainControl(
    p = 0.80, # percentage of samples used for training, rest for validation
    method  = "cv", # cross validation
    number  = 5, # 5-fold
    verboseIter = TRUE, # progress update per iteration
    classProbs = TRUE # probabilities for each example
  ),
  method = "rf", # used model algorithm
  # ntree = 500,
  importance = TRUE # calculates internal RF feature importance 
)
model
# randomForest::randomForest()

# predict (takes some time!!)
r_class <- terra::predict(datacube, model, type='raw', na.rm = TRUE)
# save classification
terra::writeRaster(r_class, '../data/LC_class_10m_crop_3035.tif',
                   datatype = "INT1U") # values from 0 to 255, no negatives

r_class <- rast('../data/LC_class_10m_crop_3035.tif')
r_class

# plot r_class
ggplot() + ggR(r_class, geom_raster = T, ggLayer = T) +
  scale_fill_manual(values = c('class_1' = "#006400", # forest
                               'class_3' = "#8b0000", # urban
                               'class_4' = "#9fba83", # vegetation
                               'class_2' = "#f4f186", # soil
                               'class_5' = "#6488ea"), # water 
                    name = "Land Cover Classification") +
  coord_sf(crs = st_crs(datacube), datum = st_crs(3035))

# plot variable importance
RF <- model$finalModel
randomForest::varImpPlot(RF) # plot

#---------------------------------------------------------------------------------------------------
# accuracy assessment of r_class with independent validation data
#---------------------------------------------------------------------------------------------------

# load independent* validation data
# * not really independent and trustworthy because collected through digitization, but should be 
#   sufficient to explain the basic concepts
val <- st_read('../data/validation_data.gpkg') %>% 
  vect()

# extract r_class values at val
val_class_1 <- terra::extract(r_class, val) 

# encoding classes LC classification
df <- data.frame(LC_levels = as.factor(c('class_1', 'class_2', 'class_3', 'class_4', 'class_5')),
                 LC_class = c('forest', 'soil', 'urban', 'vegetation', 'water'))

# create df with val (validation) and class (classification)
val_class <- cbind(val,  val_class_1[, !names(val_class_1) %in% 'ID']) %>% 
  as_tibble() %>% 
  left_join(., df, by = c('y' = 'LC_levels')) %>% 
  dplyr::select(-(one_of('y')))

# plot confusion matrix
confmat <- table(val_class)
confmat
# calculate overall accuracy
# oa <- correct predictions/total predictions
oa <- sum(diag(confmat)) / sum(confmat)
print(paste('Overall accuracy:', oa))

# calculate kappa
kappa <- kappa2(val_class[,c("LC_val", "LC_class")])
print(paste("Kappa: ", kappa$value))

#---------------------------------------------------------------------------------------------------
# accuracy assessment of r_class from cross-validation
#---------------------------------------------------------------------------------------------------

# Access the cross-validated accuracy
cv_results <- model$results
mean_accuracy <- mean(cv_results$Accuracy)

# confusion matrix for the final model
confusion <- model$finalModel$confusion

#===================================================================================================
# LEARNING TASK: 
# - remove the smoothed layers from the s2_datacube and classify again (use your own samples)
# - calculate user's/producer's accuracy (either using refernce data or cross-validated results)
#===================================================================================================

#' producer's accuracy/recall =
#' no. of pixels correctly classified as class_1/no. ground reference pixel of a class_1

#' user's accuracy/precision =
#' no. of pixels correctly classified as class_1/total no. of pixel classified as class_1




