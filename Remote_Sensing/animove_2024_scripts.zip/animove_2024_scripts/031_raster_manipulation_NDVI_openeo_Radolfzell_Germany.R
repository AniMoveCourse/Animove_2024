###########################################################################
#### Calculate NDVI using openeo and Copernicus dataspace back-end ########
###########################################################################
# link to website: https://documentation.dataspace.copernicus.eu/APIs/openEO/R_Client/R.html
# Link to cookbook with NDVI example: https://openeo.org/documentation/1.0/cookbook/#example-1-ndvi
# link to getting started: https://docs.openeo.cloud/getting-started/r/#authentication

# advantage: does not require physical download of satellite images

# load/install necessary libraries
library(openeo)
library(sf)
library(terra)
library(RStoolbox)
library(ggplot2)

#setwd(path_to_scripts_folder)

# connect to the back-end and login
connection <- openeo::connect(host = "https://openeo.dataspace.copernicus.eu")
login()
# prompts you to add login credentials on the Copernicus dataspace website
# and to press enter in console

# assign the graph-building helper object to p for easy access to all openEO processes
# see > ?processes()
p <- processes()

# create variables for loading collection
# load S2 footprint
foot <- st_read('../data/S2_footprint_3035.gpkg')  
foot_wgs84 <- st_transform(foot, 'epsg:4326')
bbox_foot <- st_bbox(foot_wgs84)

# set spatial extent to footprint
ext <- list(west = bbox_foot[[1]], south = bbox_foot[[2]], 
            east = bbox_foot[[3]], north = bbox_foot[[4]])
# temporal extent
t <- c("2023-06-13", "2023-06-13") # 1 day
# t <- c("2023-06-01", "2023-06-13") # multiple days

# load first datacube for defined spatial and temporal extent
# Sentinel-2 Level 2A
cube_s2 <- p$load_collection(
  id = "SENTINEL2_L2A",
  spatial_extent = ext,
  temporal_extent = t,
  bands=c("B04", "B08")
)

# define an NDVI function
# ndvi_function <- function(data, context) {
#   B04 <- data['B04'] # 
#   B08 <- data["B08"] #
#   
#   # ndvi <- (B08 - B04) / (B08 + B04) # implement NDVI as formula ..
#   ndvi <- p$normalized_difference(B08, B04) # or use the openEO "normalized_difference" process
#   # ndvi <- p$normalized_difference(data[2], data[3]) # or shorten all in one line
#   
#   return(ndvi)
# }

# supply the defined function to a reduce_dimension process, set dimension = "bands"
# cube_s2_ndvi <- p$reduce_dimension(data = cube_s2, reducer = ndvi_function, dimension = "bands")

# use implemented NDVI function
cube_s2_ndvi <- p$ndvi(cube_s2)

# list file formats for saving the result
formats <- list_file_formats()

# save using save_result, give format via list
res <- p$save_result(data = cube_s2_ndvi, format = formats$output$GTiff)

# send job to back-end
job <- create_job(graph = res, title = "NDVI_Radolfzell")

# start job 
start_job(job = job)

##################################
# list job status
###################################

jobs_status <- list_jobs()

jobs_ls <- lapply(1:length(jobs_status), function(i){
  df <- do.call(cbind.data.frame, jobs_status[[i]]) %>%  
    dplyr::select(created, id, status, updated)
  return(df)
})
jobs_df <- do.call(rbind, jobs_ls) %>% 
  arrange(created)

jobs_df

###############################
# list the processed results
###############################
list_results(job = job)

#########################################################
# download all the files into a folder on your computer
#########################################################
download_results(job = job, folder = "../data/NDVI_Radolfzell_openeo")

# load and plot result
NDVI_openeo <- rast('../data/NDVI_Radolfzell_openeo/openEO_2023-06-13Z.tif')

ggR(NDVI_openeo, geom_raster = TRUE)+
  scale_fill_gradient2(low = '#a60027', mid = '#fffebe', high = '#036e3a')


