###################################################################
#### Prepare downloaded Sentinel image for further processing #####
###################################################################

#' goal: 
#' - create an image stack containing 10 bands with 10m resolution 
#' - mask clouds/snow pixels
#' - crop stack to aoi extent we are interested in (Constance and surroundings)
#' - reproject stack into another coordinate system 
#' - plot colour composites

# install/load necessary libraries 
library(terra)
library(sf)
library(tidyterra)
library(maptiles)
library(ggplot2)
library(RStoolbox)

#setwd(path_to_scripts_folder)

#---------------------------------------------------------------------------------------------------
# create image stack of bands of interest with 10 m resolution
#---------------------------------------------------------------------------------------------------

# bands of interest
bands <-  c('B02_10m.jp2', 'B03_10m.jp2', 'B04_10m.jp2', # b,g,r
            'B08_10m.jp2', "B05_20m.jp2", "B06_20m.jp2", "B07_20m.jp2", # nir, 3 x red edge
            "B8A_20m.jp2", "B11_20m.jp2", "B12_20m.jp2") # nir_narrow, 2 x swir

# list band files with 10/20m resolution
bands_ls <- list.files('../data/Sentinel_2A/', recursive = TRUE, full.names = TRUE,
                       pattern = '10m.jp2|20m.jp2')

# loop through bands and select files from bands_ls
bands_ls_sub <- lapply(bands, function(i){
  file <- bands_ls[grep(bands_ls, pattern = i)]
  return(file)
})

bands_ls_sub <- unlist(bands_ls_sub)
bands_ls_sub

# separate 10 and 20 m res bands
bands_ls_10 <- bands_ls_sub[grep(bands_ls_sub, pattern = '10m')]
bands_ls_20 <- bands_ls_sub[grep(bands_ls_sub, pattern = '20m')]

# build vrts
r10 <- terra::vrt(bands_ls_10, '../data/sentinel_10m.vrt', "-separate", overwrite = T)
r20 <- terra::vrt(bands_ls_20, '../data/sentinel_20m.vrt', "-separate", overwrite = T)

####################################################################################################
### DO NOT RUN! ####################################################################################
####################################################################################################

# lets try to combine the r10/r20 stacks in one overall stack
stack <- c(r10, r20)

# resample r20 to 10m res (!! processes few mins)
r20_10res <- terra::resample(x = r20, y = r10[[1]], method = 'near') # 'near' to keep integers
## look at ppt RS practical; slide 13 for explanation on resampling methods

# combine into one layer stack
stack <- c(r10,r20_10res)

# write GEOtiff
# terra::writeRaster(stack, '../data/S2_10_Bands_10m_wgs84.tif')


####################################################################################################
####################################################################################################
####################################################################################################

# load 10m layer stack
stack <- terra::rast('../data/S2_10_Bands_10m_wgs84.tif')

#---------------------------------------------------------------------------------------------------
# generate a cloud mask and mask clouds from stack
#---------------------------------------------------------------------------------------------------

# load cloud prob layer
cloud_prob <- terra::rast(paste0(
  '../data/Sentinel_2A/S2B_MSIL2A_20230613T102609_N0509_R108_T32TMT_20230613T151004.SAFE/',
  'GRANULE/L2A_T32TMT_A032738_20230613T103453/QI_DATA/MSK_CLDPRB_20m.jp2'
  ))
# plot cloud prob layer
plot(cloud_prob)
# plot rgb for comparision
terra::plotRGB(stack, 3, 2, 1, stretch = 'lin')

# resample cloud mask to match the 10 m resolution
cloud_prob_10m <- terra::resample(cloud_prob, stack[[1]], method='near') # to keep integers

# create cloud mask
prob_thresh <- 60
cloud_mask <- terra::ifel(cloud_prob_10m > prob_thresh, NA, 1)
plot(cloud_mask)


# mask clouds from r (takes few minutes!)
#########################################
# Do not run!!!!!!!
#########################################

stack_crm <- terra::mask(stack, cloud_mask)
# terra::writeRaster(stack_crm, '../data/S2_10_Bands_10m_msk_clouds_wgs84.tif')

stack_crm <- terra::rast('../data/S2_10_Bands_10m_msk_clouds_wgs84.tif') 
# plot
# without masked clouds
plot(stack[[3]])
# with masked clouds
plot(stack_crm[[3]])

#===================================================================================================
# LEARNING TASK: create snow mask and mask snow pixels using MSK_SNWPRB_20m.jp2
#===================================================================================================

#---------------------------------------------------------------------------------------------------
# crop image to aoi extent of region around the city Constance
#---------------------------------------------------------------------------------------------------

########## crop stack with aoi ##########

# load aoi
aoi <- st_read('../data/AOI_constance.gpkg')

# check reference system of aoi
st_crs(aoi)

# get crs from stack_crm
crs_stack <- terra::crs(stack_crm)

# project aoi to the crs of stack crm
aoi_proj <- st_transform(aoi, crs = crs_stack) # can also be applied with crs = 'epsg:32632'
st_crs(aoi_proj)

# get footprint of stack_crm
s2_footprint <- st_as_sfc(st_bbox(stack_crm))

# plot s2 footprint and aoi
ggRGB(stack_crm, 
      r = 3, 
      g = 2,
      b = 1, stretch = 'lin', geom_raster = TRUE) +
  geom_sf(data = s2_footprint, color = 'red', fill = NA, lwd = 1) +
  geom_sf(data = aoi_proj, color = 'purple', fill = NA, lwd = 1)


# crop stack_crm with aoi_proj
stack_crop <- terra::crop(stack_crm, aoi_proj)

# plot cropped extent
ggRGB(stack_crop, 3,2,1, stretch = 'lin', geom_raster = TRUE)+
  geom_sf(data = aoi_proj, color = 'purple', fill = NA, lwd = 1)

########## alternative: crop using extent coordinates ##########

# load fake trajectory data
traj <- st_read('../data/fake_trajectory.gpkg')

# reproject traj
traj_proj <- sf::st_transform(traj, crs = crs_stack)

# plot traj on top of map

# get osm tile
osm_tile <- get_tiles(traj_proj, 
                  zoom = 10,
                  crop = TRUE
)

# plot traj on osm tile
ggplot2:: ggplot() +
  geom_spatraster_rgb(data = osm_tile) +
  ggplot2::geom_sf(
    data = traj_proj,
    color = "red",
    fill = "red"
  ) +
  ggplot2::coord_sf(expand = FALSE)

# get bbox of traj
ext <- sf::st_bbox(st_buffer(traj_proj, dist = 1000))
# create sf object (just for plotting)
ext_sf <- st_as_sfc(ext)

# plot traj on tile with ext_sf
ggplot2:: ggplot() +
  geom_spatraster_rgb(data = tile) +
  ggplot2::geom_sf(
    data = traj_proj,
    color = "red",
    fill = "red"
  ) +
  ggplot2::geom_sf(
    data = ext_sf, fill = NA, color = 'purple', lwd = 1) +
  ggplot2::coord_sf(expand = FALSE)

# crop
stack_crop_traj <- crop(stack_crm, ext)


# plot cropped raster + traj_proj
ggRGB(stack_crop_traj,  
      r = 3, g = 2, b = 1,
      stretch = 'lin', 
      geom_raster = TRUE) +
  ggplot2::geom_sf(data = traj_proj,
                   color = 'red', fill = 'red')


#---------------------------------------------------------------------------------------------------
# reproject stack into a new coordinate system
#---------------------------------------------------------------------------------------------------

# first let's check the current crs 
terra::crs(stack_crop)

# specify new crs: new coordinate system: ETRS89-extended / LAEA Europe EPSG:3035 
crs_new <- st_crs(3035)


#################################
# DO not run!!
#################################
# project raster (computes a bit)
stack_3035 <- terra::project(stack_crop, y = crs_new$wkt, # y can also be 'EPSG:3035' instead of crs_new$wkt
                             method = 'near') # see resampling ppt slide 

# save reprojected raster stack
# terra::writeRaster(stack_3035, '../data/S2_10_Bands_10m_crop_3035.tif')

# load projected and cropped stack
stack_3035 <- terra::rast('../data/S2_10_Bands_10m_crop_3035.tif')
# check crs again
crs(stack_3035)

#---------------------------------------------------------------------------------------------------
# plot colour composites
#---------------------------------------------------------------------------------------------------

# add bandnames for easier handling
bandnames <- gsub(bands, pattern = '.jp2', replacement = '')
names(stack_3035) <- bandnames

# link to webpage with sentinel-2 bandnames and common band combinations:
# https://gisgeography.com/sentinel-2-bands-combinations/
  

# true colour composite (red, green, blue)
terra::plotRGB(stack_3035, r=3, g=2, b=1, stretch = 'lin') 
# if you only want to plot two layer composites set one of the r/g/b variables to NULL

# False colour composite with (nir, green, red)
# commonly used for vegetation monitoring
terra::plotRGB(stack_3035, r=4, g=2, b=3, stretch = 'lin')

# False colour composite 
# commonly used for agricultural monitoring (swir, red, blue)
terra::plotRGB(stack_3035, r=10, g=4, b=1, stretch = 'lin')

# plot raster as well as aoi and animove location on top using RStoolbox functionalities
# reproject aoi to 3035
aoi_3035 <- st_transform(aoi,crs = 3035)
# load AniMove 2024 location
animove <- st_read('../data/animove_2024_location.gpkg')
crs(animove)

# ggRGB works with ggplot2 layers 
ggRGB(stack_3035, r=3, g=2, b=1, stretch = "lin", geom_raster = TRUE) + 
  ggplot2::geom_sf(data=aoi_3035, colour = "deepskyblue", fill = "transparent") +
  ggplot2::geom_sf(data=animove, colour = 'red', fill = 'red', size = 2)

#===================================================================================================
# LEARNING TASK: 
# - try out some false colour composites from the S2 data using terra::plotRGB and RStoolbox::ggRGB
# - look at this website for inspiration: 
# https://custom-scripts.sentinel-hub.com/custom-scripts/sentinel-2/composites/
#===================================================================================================


