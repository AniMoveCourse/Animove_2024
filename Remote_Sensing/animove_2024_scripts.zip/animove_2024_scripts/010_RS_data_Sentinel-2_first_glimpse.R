################################################################
#### First view on/inspection of downloaded Sentinel image #####
################################################################

#' goal: 
#' - get a first glimpse of the downloaded data

### install/load necessary libraries
library(terra)

#setwd(path_to_scripts_folder)

#---------------------------------------------------------------------------------------------------
# Data inspection of a single tile 
#---------------------------------------------------------------------------------------------------

# unzip the downloaded Sentinel file
zip_file <- list.files('../data/Sentinel_2A/', full.names = TRUE)
unzip_dir <- paste0(head(strsplit(zip_file, "/")[[1]], n=-1), collapse = "/")
unzip(zip_file, exdir = unzip_dir)

# look at "../data/Sentinel_2A" 

# index only image files, we would like to use the 10 m sentinel-2 files
jp2_files <- list.files(unzip_dir, recursive = T, full.name = T, pattern = "10m.jp2")
jp2_bands <- grep("_B", jp2_files, value = T)

# create raster vrt
# filename
vrt_file <- gsub(".zip", "_IMG_R10m_BANDS.vrt", zip_file)
# build vrt
terra::vrt(jp2_bands, vrt_file, "-separate", overwrite = T) 
# open vrt in text editor

# read vrt with terra
r <- terra::rast(vrt_file)
# metadata
r

# plots all of the selected bands side-by-side
plot(r)

# indexing
r[[1]] # gives you information on the first layer in the stack
names(r)
# can also be queried by name
r[["S2B_MSIL2A_20230613T102609_N0509_R108_T32TMT_20230613T151004.SAFE_IMG_R10m_BANDS_1"]]

# plot the 3rd layer in the layer stack 
plot(r[[3]])

# plot an rgb image
terra::plotRGB(x = r, r = 3, g = 2, b = 1, stretch= 'lin')

# plot histogram (distribution of cell values)
terra::hist(r[[1]], breaks = 100)

# extracts all cell values
val <- terra::values(r[[1]])
max(val)
min(val)
hist(val, breaks = 100)
