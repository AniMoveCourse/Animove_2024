###########################################
###### Align and Stack raster layers ######
###########################################
# script from Martina Scacco

# load/install necessary libraries
library(terra)


# create two example raster layers
# r1
r1 <- rast(ncol=7, nrow=4,
           vals=c(0,1),
           xmin=0, xmax=10, ymin=-5, ymax=0,
           crs="EPSG:4326")
r1

r2 <- rast(ncol=5, nrow=5,
           vals=c(0,1),
           xmin=0, xmax=577000, ymin=-615000, ymax=0,
           crs="ESRI:54032")
r2

par(mfrow=c(1,2))
plot(r1, main="raster latlong")
plot(r2, main="raster equid")

### How do we stack them?

####################################################################################################
# How to not do it
####################################################################################################

## Match only projection

# reproject using method 'bilinear' (does change original raster values)
r2Prj <- project(x=r2, y=crs(r1), method="bilinear") # here argument y is a crs
plot(r2); plot(r2Prj) # notice values went from binary 0-1 to continuous 0 to 1

# reproject using method 'near' (does not change original raster values)
r2Prj <- project(r2, y=crs(r1), method="near")
plot(r2); plot(r2Prj)

# plot reprojected
par(mfrow=c(1,1))
plot(r1, col=c("white","red"))
plot(r2Prj, add=T)

# Try to stack
s <- c(r1, r2Prj) # extents do not match

## Match extent
plot(ext(r1), col="red"); plot(ext(r2Prj), add=T, col="blue")
ext(r2Prj); ext(r1)

# option 1 crop
r1Crop <- crop(r1, ext(r2Prj))
plot(ext(r1Crop), col="red"); plot(ext(r2Prj), add=T, col="blue")
ext(r2Prj); ext(r1Crop)

# option 2 extend
r2PrjExt <- extend(r2Prj, ext(r1)) #fill=NA by default
plot(ext(r2PrjExt), col="red"); plot(ext(r1), col="blue", add=T)
par(mfrow=c(2,1))
plot(r1); plot(r2PrjExt, main="Extended raster")

summary(r2)
summary(r2PrjExt)

# Try to stack again, still extents don't exactly match, because the pixel sizes are different
s <- c(r1Crop, r2Prj)
s <- c(r1, r2PrjExt)

## Match resolution
res(r2Prj)
res(r1Crop)
res(r2Prj)/res(r1Crop) 

# if res1/res2 gives an integer value, then we could use aggregate or disaggregate to match the resolutions
# and then use crop to get the exact same extent before stacking
# in this case the resolution are quite different and what we can do it set the resolution of one to the other

# Since resolutions are so different we need to use resample
# BUT they have to be in the same crs

r2Resampled <- resample(r2Prj, r1, method="near")
# compare r1 with r2Resampled
r1
r2Resampled

s <- c(r1, r2Resampled)
s
plot(s)

# Try all other possibilities before resample

####################################################################################################
# How to do it!
####################################################################################################

### A much easier way to do the same is simply using the function "project"
### having as second argument the raster that we want to use as template
### All the above operations (aligning extent, pixel resolution and crs) will be performed internally

r2Resampled_2 <- project(r2, r1)
s <- c(r1, r2Resampled_2)
plot(s)

r2Resampled_2 <- project(r2, r1, method="near")
s <- c(r1, r2Resampled_2)
plot(s)



