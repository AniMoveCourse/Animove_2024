###################################################################
#### Calculate new raster layers to obtain spatial information ####
###################################################################

#' goal: 
#' - calculate a new raster layer based on vector data (distance to streets)
#' - calculate a new raster layer by aggregating information from multiple pixels (spatial filtering)
#' - calculate a new raster layer from different RS raster layers (NDVI)


### install/load necessary libraries
library(terra)
library(sf)
library(RStoolbox)
library(ggplot2)

#setwd(path_to_scripts_folder)

#---------------------------------------------------------------------------------------------------
# calculate a new raster layer based on vector data (distance to streets)
#---------------------------------------------------------------------------------------------------

# load OSM streets
# primary, secondary and tertiary roads
# downloaded via https://overpass-turbo.eu/
streets <- st_read('../data/streets_S2_footprint_3035.gpkg')


# load S2 stack
S2 <- rast('../data/S2_10_Bands_10m_crop_3035.tif')

# plot streets on top of S2 rgb
ggRGB(S2, r=3, g=2, b=1, stretch = "lin", geom_raster = TRUE) + 
  ggplot2::geom_sf(data=streets, colour = 'red') 

### calculate distance to streets for each pixel in S2

# convert streets to spatvec
streets_vec <- terra::vect(streets)

# calculate distance to all streets (takes some time to compute)
## If y is a SpatVector, the distance to that SpatVector is computed for all cells. 
dist <- terra::distance(S2[[1]], streets_vec, unit = 'm')
# save dist layer
# terra::writeRaster(dist, '../data/Distance_10m_crop_3035.tif')

# load dist
dist <- rast('../data/Distance_10m_crop_3035.tif')

# plot streets on top of new dist layer for inspection
ggR(dist, geom_raster = TRUE) + # ggR() for plotting a single raster layer
  ggplot2::geom_sf(data=streets, colour = 'red') 


#---------------------------------------------------------------------------------------------------
# calculate a new raster layer by aggregating information from multiple pixels (spatial filtering)
#---------------------------------------------------------------------------------------------------

# load global human settlement layer 
# available from here: https://human-settlement.emergency.copernicus.eu/download.php
# The spatial raster dataset (ghs-built-s) depicts the distribution of built-up surfaces, 
# in % (originally 100 * 100 m res but here resampled to 
# 10 * 10 m res of S2)
ghs <- terra::rast('../data/GHS_10m_crop_3035.tif')
ghs

# plot ghs
ggR(ghs, stretch = 'lin', geom_raster = TRUE)

################ edge detection #######################

# define the 9x9 Sobel operator for edge detection
sobel_y <- matrix(c(-1, -2, -1, 0, 0, 0, 1, 2, 1), nrow=9, ncol=9)
sobel_x <- t(sobel_y)  # transpose of sobel_x

# apply the Sobel operator to the raster using focal() function
edges_x <- focal(ghs, w=sobel_x) # calculates edges in x-direction
edges_y <- focal(ghs, w=sobel_y) # calculates edges in y-direction

# plot
ggR(edges_x, geom_raster = TRUE)
ggR(edges_y, geom_raster = TRUE)

# combine the edge detections in x and y directions
# ^2: makes all raster values positive/sqrt: from quadratic back to linear scale 
edges <- sqrt(edges_x^2 + edges_y^2) 
# result: absolut magnitude of edges in x-y direction

# plot original ghs layer 
ggR(ghs, geom_raster = TRUE)
# plot edges
ggR(edges, geom_raster = TRUE)

# save to drive
terra::writeRaster(edges, '../data/edges_10m_crop_3035.tif', overwrite = TRUE)

#===================================================================================================
# LEARNING TASK: 
# - create an edges layer (edges_nir) using the sobol x-y operators on the NIR band in S2 (S2[[4]])
# - save the result to the to drive ('../data/edges_nir_10m_crop_3035.tif')
#===================================================================================================

################### smoothing #########################

# spatial aggregation using focal() function
# define focal matrix (moving window: here rectangle)
# d = specifies radius in m
foc_mat <- focalMat(ghs, d = c(300,300), type = "rectangle")
foc_mat 
# adapts to an odd number of  cells, where values are calculated for the center cell of foc_mat

# resulting weights (values in foc_mat) should add up to 1
# sum(foc_mat)
# ensures that brightness, when plotting the image is similar to original brightness in a raster

#' However, there are cases where the weights in the filter do not necessarily need to add up to one. 
#' For example, in edge detection filters like the Sobel filter.
#' This is because the goal of edge detection is not to preserve the original image intensity, 
#' but to highlight the areas of the image where the intensity changes sharply (i.e., the edges).

# apply foc_mat for smoothing using focal() function
# CAUTION: as d (see above: focalMat() function) increases also the computation time increases, 
# as more cells are considered to calculate, for instance, the sum
smooth_300 <- terra::focal(w = foc_mat, x = ghs, fun = "sum", na.rm = TRUE)
# save to drive
terra::writeRaster(smooth_300, '../data/smooth_300_10m_crop_3035.tif')

# plot original ghs layer 
plot(ghs)
# plot smoothed ghs layer
smooth_300 <- rast('../data/smooth_300_10m_crop_3035.tif')
plot(smooth_300)


# load smooth_500
smooth_500 <- terra::rast('../data/smooth_500_10m_crop_3035.tif') 
plot(smooth_500)


#---------------------------------------------------------------------------------------------------
# calculate a new raster layer from different RS raster layers (NDVI)
#---------------------------------------------------------------------------------------------------

# calculate NDVI
# equation: (nir - red)/(nir + red) 

# Sentinel-2: nir = B08 and red = B04

# add band names to S2
names(S2)
# vector with original S2 bandnames
bandnames <- c("B02", "B03", "B04",  "B08", "B05", "B06", "B07", "B08a", "B11", "B12")
# change bandnames 
names(S2) <- bandnames
names(S2)

################### NDVI using band indexing ###########################

NDVI <- (S2["B08"] - S2["B04"])/(S2["B08"] + S2["B04"])

################### NDVI using terra::app() function ################### 

NDVI <- terra::app(S2, 
                   fun = function(r)(r['B08'] - r['B04'])/(r['B08'] + r['B04']))

writeRaster(NDVI, '../data/S2_NDVI_terra_app.tif', overwrite = TRUE)

ggR(NDVI, geom_raster = TRUE)+
  scale_fill_gradient2(low = '#a60027', mid = '#fffebe', high = '#036e3a')
  # scale_fill_gradientn(colors=grey.colors(100), guide = "none")

################### NDVI using RStoolbox::spectralIndices() function ################### 

# RStoolbox requires values in bands to be in the range of c(0,1)

r_norm <- normImage(S2) # center and scaling to sd
r_resc <- rescaleImage(r_norm, ymin=0, ymax=1) # reflectance range 0 to 1
names(r_resc)
# calculate NDVI for Sentinel-2:
# returns a layer stack if multiple indices are calculated
r_indices <- spectralIndices(
  r_resc,
  blue = 1,
  green = 2,
  red = 3,
  nir = 4,
  redEdge1 = 5,
  redEdge2 = 6,
  redEdge3 = 7,
  swir2 = 9,
  swir3 = 10,
  indices = c("NDVI")
)

ggR(r_indices, geom_raster = TRUE)+
  scale_fill_gradient2(low = '#a60027', mid = '#fffebe', high = '#036e3a')
  # scale_fill_gradient2(low = '#a60027', mid = '#fffebe', high = '#00008b')

# save NDVI
terra::writeRaster(r_indices, '../data/NDVI_10m_crop_3035.tif', overwrite = TRUE)

#===================================================================================================
# LEARNING TASK: 
# - calculate Normalised Difference Water Index (NDWI) and Enhanced Vegetation Index (EVI)
# - save NDWI to drive: '../data/NDWI_10m_crop_3035.tif' 
#===================================================================================================

